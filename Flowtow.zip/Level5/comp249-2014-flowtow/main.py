'''
Created on Mar 30, 2014

@author: Brett Sargeant
'''
import database
from templating import render

from interface import list_comments
from interface import add_comment
from interface import list_images
from interface import add_image
from interface import add_avatar
from interface import list_images_for_user
from interface import add_user
from interface import delete_image
from interface import check_image

from users import check_login
from users import user_from_cookie
from users import generate_session
from users import delete_session
from users import nick_from_cookie
from users import avatar_from_nick
from users import update_email
from users import update_nick
from users import update_avatar
from users import get_users
from users import check_password
from users import update_password

import http.cookies

import os, sys
import cgi

def content_type(path):
    """Return a guess at the mime type for this path
    based on the file extension"""
    
    #table to check the extension of the file given
    MIME_TABLE = {'.txt': 'text/plain',
              '.html': 'text/html',
              '.css': 'text/css',
              '.js': 'application/javascript',
              '.jpeg': 'image/jpeg',
              '.jpg': 'image/jpeg',
              '.png': 'image/png',
              '.tiff': 'image/tiff',
              '.gif': "image/gif"
             }  
    
    #splits the file extension from the path
    name, ext = os.path.splitext(path)
    
    #checks the extension in the mime table and returns appropriate header content
    if ext in MIME_TABLE:
        return MIME_TABLE[ext]
    else:
        return "application/octet-stream"

def get_menu(environ):
    """This function generates the menu bar for max customize-ability"""
    #gets the current session from the cookie
    session = user_from_cookie(db, environ)
    #checks if the session is active and returns my images and my profile if applicable
    if session != None:
        my_images = """\n<li><a href="/my">My Images</a></li>\n<li><a href="/profile">My Profile</a></li>\n"""
        #checks if the logged in user is the admin
        if session == "admin":
            my_images += """</a></li>\n<li><a href="/users">User List</a></li>\n"""
    #returns the register tab if not logged in     
    else:
        my_images = """\n<li><a href="/reg">Register</a></li>\n"""
    #writes the basic menu
    menu = """            <a class="menu-brand" href="/">FlowTow</a>
            <ul>
               <li><a href="/">Home</a></li>
               <li><a href="/about/">About</a></li>%s
            </ul>""" % my_images
    return menu
    
def get_images(environ, num):
    """This function gets the images from the database, displays the date added,
        user's email, displays the image and compiles the comments. It then creates
        a form so comments can be added to the image's comment database."""
        
    #assigns the images from the database to listdata
    listdata = list_images(db, num)
    html = ""
    count = 0
    
    #This for loop iterates over each image in listdata
    for item in listdata:
        changedate = item[1]
        changedate = changedate.rpartition(' ')[0]
        html += """
    <div class='flowtow'>
        <div class='container_info'>
            <p><span class='date'>%s</span><span class='name'>%s</span></p>
            <br class="clear_float"/>
        </div>
        <img class='image_post' src='static/images/%s' name='image%s'/>
        <div class='comcontainer'>
        """ % (changedate, item[2], item[0], count)
            
        count2 = 0
        #This for loop iterates over each comment for the image
        for comment in item[3]:
            nick = cgi.escape(item[3][count2][1])
            avatar = item[3][count2][2]
#             avatar = avatar_from_nick(db, environ)
            print(avatar, "this had better be working")
            
            #checks if the avatar image is there
            avatar = check_image(db, avatar)
            #set the default avatar
            if avatar == "default":
                avatar = "cycling.jpg"
            avatar = "<img class='avatar_pic' src='static/images/%s'/>" % cgi.escape(avatar)
            
            html +="""
            <div class="test-comment-container">
                <div class="test-pic">%s</div>
                <div class="cc">
                    <div class='test-user-alias'><h4>%s</h4></div>
                    <div class="test-comment">%s</div>
                </div>
                <br class="clear_float" />
            </div>
            """  % (avatar, nick, cgi.escape(item[3][count2][0]) )
            count2 += 1
        html += """
        <br class='clear_float'/>
        </div>
        <form role='form' method='POST' action='comment'>
            <input type='hidden' name='image' value='%s'>
            <input class='form-control' type='text' name='comment' placeholder='Enter your comment here'>
            <input class='btn btn-primary' type='submit' value='Submit Comment'>
        </form>    
    </div>\n""" % (item[0])
        count += 1
    return html

def static_app(environ, start_response):
    """Serve static files from directory"""
    # joins the file location to the standard path
    STATIC_FILE_DIR = os.path.join(os.path.dirname(__file__), 'static')
#     print(STATIC_FILE_DIR, "Static File DIR")

    path = environ['PATH_INFO']

    #remove '/static'
    path = path.replace('/static', STATIC_FILE_DIR)
    
    #if the path exists, write file to the path
    if os.path.exists(path):
        h = open(path, 'rb')
        content = h.read()
        h.close()
        
        start_response('200 OK', [('content-type',content_type(path))])
        return [content]
    else:
        start_response('200 OK', ('content-type', 'text/text'))
        return "path does not exist"
        
def show_404_app(environ, start_response):
    """Simple app to display that the page directory was not found"""
    
    title = "404: Page not found"
    content = "<div class='default-text'><p>This is not the page you are looking for...</p></div>"
    start_response("404 Not Found", [('content-type', 'text/html')])
    return title, content

def comment_added_app(environ, start_response):
    """An app to check of a comment has been submitted, if true then
        return a 303 redirectory response and add comment to database"""
        
    title = 'Comment added to FlowTow'
    content = "Time to be redirected"
    #get the submitted data from the form
    form = cgi.FieldStorage(environ=environ, fp=environ['wsgi.input'])
    submitted = form.getvalue("comment", "")
    filename = form.getvalue("image", "")

    #if something was submitted, add the avatar and nickname for it
    if submitted:
        nick = nick_from_cookie(db, environ)
        avatar = avatar_from_nick(db, environ)
        print(avatar, "THis is a avt in comment subs")
        
        #if there is no set nickname, set to anonymous
        if nick != None:
           nick = nick[0][0]
        else:
            nick = "Anonymous"
            
        #if no set avatar, set to default
        if avatar != None:
            avatar = avatar[0][0]
        else:
            avatar = "default"
            
        #add the comment to the database
        add_comment(db, filename, submitted, nick, avatar)
    start_response("303 See Other", [('content-type', 'text/html'), ('location', '/')])
    return title, content

def get_login_data(environ, start_response):
    """This app check if there is any login input, then encrypts
        the password and checks it with the database. If the email
        or password return false, it displays a login error message"""
        
    COOKIE_NAME = "sessionid"
    session = user_from_cookie(db, environ)
        
    form = cgi.FieldStorage(environ=environ, fp=environ['wsgi.input'])
    email = form.getvalue("email", "")
    password = form.getvalue("password", "")
    header = [('content-type', 'text/html'), ('location', '/')]
    checkpass = check_login(db, email, password)
    
    #if "logout" name is found in the login form, assume that you are logged in
    if "logout" in form:
        session = delete_session(db, user_from_cookie(db, environ))
        title = 'Checking login data'
        content = "Time to be redirected"
        start_response("303 See Other", header)
        return title, content
    
    #if there is an email added, there is a current session and the password is true, use that session
    elif email != "" and session != "" and checkpass == True:
        print("Session Found")
#         session = delete_session(db, session)
        session = generate_session(db, email)
        session = session[COOKIE_NAME].OutputString()
        header.append(('Set-Cookie', session))
        title = 'Checking login data'
        content = "Time to be redirected"
        start_response("303 See Other", header)
    
    #if there is an email added, no current session and the password is true, generate a new session  
    elif email != "" and session == "" and checkpass == True:
#         delete_session(db, email)
        session = generate_session(db, email)
        print("No Session found")
        session = session[COOKIE_NAME].OutputString()
        header.append(('Set-Cookie', session))
        title = 'Checking login data'
        content = "Time to be redirected"
        start_response("303 See Other", header)
        
    #if no email or password not correct, produce a login error
    else: 
        title = "LOGIN ERROR"
        content = """<div class="default-text"
        <p>Login Failed, please try again</p>
</div"""
        start_response("200 OK", [('content-type', 'text/html')])
 
    return title, content
    
def generate_login_form(environ):
    """This function generates the login form to be used in the 
        menu navigation bar"""
    
    #get current session
    session = user_from_cookie(db, environ)
    #if there is a session, generate logout form
    if session != None:
        login_form = """
                <form id='logoutform' class="logout" role="logout" method='post' action='/login'>
                    <input type="submit" class="btn btn-default" name='logout' value='Logout' >
                </form>
                <div class="loggedintext">Logged in as %s</div>""" % session
    #else generate login form
    else:
        login_form = """
                <form id="loginform" class="login" role="login" method="post" action="/login">
                    <div class="form-group">
                        <input type="text" name='email' class="form-control" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <input type="password" name='password' class="form-control" placeholder="Password">
                    </div>                
                    <input type="submit" class="btn btn-default" value='Login' >
                </form>"""
    
    return login_form

def uploads_form(email):
    """This function generates the upload forms contained in /myimages"""
    
    #generate a upload form
    html = """
    <form id='uploadform' method='post' action='/upload' enctype="multipart/form-data">
        <fieldset class='form-group'>
            <legend>Upload New Image</legend>
            <input class='form-control' type='file' name='file'>
            <input type='hidden' name='user' value='%s'>
            <input class='btn btn-primary' type='submit' value="Upload File">
        </fieldset>
    </form>
 """ % email
    
    return html

def upload_avatar_form(email):
    """This function generates the upload forms contained in /profile"""
    
    #generate an upload form for avatars
    html = """
    <form id='uploadavatar' method='post' action='/avatar' enctype="multipart/form-data">
        <fieldset class='form-group'>
            <legend>Upload New Avatar</legend>
            <input class='form-control' type='file' name='file'>
            <input type='hidden' name='user' value='%s'>
            <input class='btn btn-primary' type='submit' value="Upload File">
        </fieldset>
    </form>
 """ % email #substitute the email in the html code
    
    return html

def upload_image(environ, start_response):
    """This function checks if there has been a file added to the upload form,
        and if so it will load that file into the /static/images folder."""
        
    formdata = cgi.FieldStorage(environ=environ, fp=environ['wsgi.input'])
    email  = user_from_cookie(db, environ)
    
    if 'file' in formdata and formdata['file'].filename != '':
        
        file_data = formdata['file'].file.read()
        filename = formdata['file'].filename

        #direct to the images folder inside static folder
        IMAGES_FILE_DIR = os.path.join(os.path.dirname(__file__), 'static' + '\images')
        path  = IMAGES_FILE_DIR
        #add the filename to the target path
        target = os.path.join(IMAGES_FILE_DIR, filename)
        target = os.path.normpath(target)
        
        #check if path actually exists
        if os.path.exists(path):
            
            #try to add the file
            addimg = add_image(db, filename, email)
            
            #if file exists show error
            if addimg == False:
                title = "Upload Error"
                content = "<div class='default-text'><p>Could not upload file, file name already exists</p></div>"
                start_response("200 OK", [('content-type', 'text/html')])
                
            # write the content of the uploaded file to a local file
            else:
                f = open(target, 'wb')
                f.write(file_data)
                f.close()  
                print("added image to file")
                
                title = "UPLOAD"
                content = "Uploading"
                start_response("303 See Other", [('content-type', 'text/html'), ('location', '/my')])
                
        #show that path does not exist
        else:
            title = "Upload Error"
            content = "<div class='default-text'><p>Could not upload file\nNo path</p></div>"
            start_response("200 OK", [('content-type', 'text/html')])
            
    #user didnt enter any content
    else:
        title = "Did he just click that button with no filename?"
        content = "I think he just did... Let's just ignore him until he stops..."
        start_response("303 See Other", [('content-type', 'text/html'), ('location', '/my')])
    return title, content
        

def get_my_images(environ, start_response):
    """This function is to display the page for the logged
        in user's image profile."""
    #get users email from cookie
    email  = user_from_cookie(db, environ)
    
    #check if logged in
    if email == None:
         title = "My Images"
         html = "<div class='default-text'><p>You need to log in to see this page</p></div>"
    
    #display all the users images
    else:
        listdata = list_images_for_user(db, email)
        print(listdata)
        
        title = "My Images"
        html = uploads_form(email)
        count = 0

        #This for loop iterates over each image in listdata
        for item in listdata:
            changedate = item[1]
            #change the date to only show year month and day
            changedate = changedate.rpartition(' ')[0]
            html += """
        <div class='flowtow'>
            <div class='container_info'>
                <p><span class='date'>%s</span><span class='name'>%s</span></p>
                <br class="clear_float"/>
            </div>
            <img class='image_post' src='static/images/%s' name='image%s'/>
                        <div class='comcontainer'>
            """ % (changedate, item[2], item[0], count)
                
            count2 = 0
            #This for loop iterates over each comment for the image
            for comment in item[3]:
                
                #make sure no invalid characters
                nick = cgi.escape(item[3][count2][1])
                avatar = item[3][count2][2]
                
                #if no nickname, assign anonymous
                if nick == None or nick == "":
                    nick = "Anonymous"
                
                #get avatar for comments
                avatar = check_image(db, avatar)
                
                if avatar == "default":
                    avatar = "cycling.jpg"
                avatar = "<img class='avatar_pic' src='static/images/%s'/>" % cgi.escape(avatar)
                html +="""
                <div class="test-comment-container">
                    <div class="test-pic">%s</div>
                    <div class="cc">
                        <div class='test-user-alias'><h4>%s</h4></div>
                        <div class="test-comment">%s</div>
                    </div>
                    <br class="clear_float" />
                </div>
                """  % (avatar, nick, cgi.escape(item[3][count2][0]) )
                count2 += 1
            html += """
            <br class='clear_float'/>
            </div>
            <form role='form' method='POST' action='comment'>
                <input type='hidden' name='image' value='%s'>
                <input class='form-control' type='text' name='comment' placeholder='Enter your comment here'>
                <input class='btn btn-primary' type='submit' value='Submit Comment'>
            </form>    
                <div class='delete-btn'>
                <form role='form' method='POST' action='delete'>
                    <input type='hidden' name='image' value='%s'/>
                    <input class='btn btn-primary' type='submit' value='Delete Image'/>
                </form>
                </div>
            </div>\n""" % (item[0], item[0])
            count += 1
    start_response("200 OK", [('content-type', 'text/html')])
         
    return title, html

def register_app(environ, start_response):
    """An app to let the non-logged in user to make an account"""
    title = "Register"
    added = False
    #added = add_user(db, "brett@email.com", "brett", "sarge", "brett" )
    
    content = """<div class='default-text'><p>Please enter your email, password, prefered nickname and avatar</p></div>
        <form id="create-user" class="create" role="create" method="post" action="/create">
            <div class="form-group">
                <span class='create-text'>Email</span><input class='create-box' type="text" name='email' class="form-control" placeholder="Email">
            </div>
            <br class='clear_float'/>
            <br class='clear_float'/>
            <br class='clear_float'/>
            <div class="form-group">
                <span class='create-text'>Password</span><input class='create-box' type="password" name='password' class="form-control" placeholder="Password">
            </div> 
            <br class='clear_float'/>
            <br class='clear_float'/>
            <br class='clear_float'/>
            <div class="form-group">
                <span class='create-text'>Nickname</span><input class='create-box' type="text" name='nick' class="form-control" placeholder="Nickname">
            </div>
            <br class='clear_float'/>
            <br class='clear_float'/>
            <br class='clear_float'/>
            <div class="form-group">
               <span class='create-text'>Avatar</span><input class='create-box' type="text" name='avatar' class="form-control" placeholder="Avatar">
            </div>    
            <br class='clear_float'/> 
            <br class='clear_float'/>
            <br class='clear_float'/>               
            <input type="submit" class="btn btn-default" value='Create' >
        </form>"""
    
    start_response("200 OK", [('content-type', 'text/html')])
    return title, content

def add_regi(environ, start_response):
    """Application which adds the user to the database"""
    #get the form data entered
    form = cgi.FieldStorage(environ=environ, fp=environ['wsgi.input'])
    
    #assign each data
    email = form.getvalue("email", "")
    password = form.getvalue("password", "")
    nick = form.getvalue("nick", "")
    avatar = form.getvalue("avatar", "")
    
    title = "Create"
    
    #check if each box is filled out
    if email == "" or password == "" or nick == "" or avatar == "":
        content = "<div class='default-text'><p>Sorry but you missed a box!</p></div>"
    else:
        added = add_user(db, email, password, nick, avatar)
        #check if email already exists
        if added == False:
            content = "<div class='default-text'><p>Sorry but that email has already been registered!</p></div>"
        else:
            content = "<div class='default-text'><p>Congratulations! You have registered!</p></div>"
        
    start_response("200 OK", [('content-type', 'text/html')])
    return title, content
    
def delete_image_app(environ, start_response):
    """Application to delete the selected image from the database"""
    
    #get data from form
    form = cgi.FieldStorage(environ=environ, fp=environ['wsgi.input'])
    filename = form.getvalue("image", "")
    email  = user_from_cookie(db, environ)
    
    #check that filename and email both exist
    if filename != "" and email != None:
        title = "Delete"
        content = "Deleting image"
        
        #delete specified image
        delete_image(db, filename, email)
        start_response("303 See Other", [('content-type', 'text/html'), ('location', '/my')])
    
    #If filename or email dont exist, throw error
    else:
        title = "Cant Delete"
        content = "Cant Delete"
        start_response("303 See Other", [('content-type', 'text/html'), ('location', '/my')])
    return title, content
    
def profile_app(environ, start_response):
    """App to get profile information to change password etc."""
    
    #get profile info from cookie
    email  = user_from_cookie(db, environ)
    nick = nick_from_cookie(db, environ)[0][0]
    avatar = avatar_from_nick(db, environ)[0][0]
    
    #if avatar is default, give a default image 
    if check_image(db, avatar) == False:
        avatar = "default"
        print("Avatar not found - Set to default")
    if avatar == "default":
        avatar = "cycling.jpg"
    
    #check that user logged in
    if email == None or nick == None or avatar == None:
         title = "Profile"
         content = "<div class='default-text'><p>You need to log in to see this page</p></div>"
    else:
        title = "Profile"
        content = """<div class='default-text'><p>Hello %s,\n here you can change your email, password, nickname or avatar</p></div>
<div class='profile_info_container'>
    <div class="profile-pic"><img class='avatar_pic' src='static/images/%s'/></div>
    <div class='profile-container'>
        <div class='profile-user-alias'><h4>%s</h4></div>
        <div class='profile-user-email'><h6>%s</h6></div>
    </div>
    %s
    <br class="clear_float" />
</div>

<div class='profile_info_container'>
    <form id="create-user" class="create" role="create" method="post" action="/update">
        <div class="form-group">
            <div class='update-container' >
                <div class='update-text-container'>
                    <span class='update-text'>Email</span>
                    <span class='update-text'>Password</span>
                    <span class='update-text'>Nickname</span>
                </div>
                
                <div class='update-box-container'>
                    <input class='update-box' type="text" name='email' class="form-control" placeholder="Email">
                    <input class='update-box' type="text" name='confirmemail' class="form-control" placeholder="Confirm Email">
                    <input class='update-box' type="password" name='password' class="form-control" placeholder="Password">
                    <input class='update-box' type="password" name='newpassword' class="form-control" placeholder="New Password">
                    <input class='update-box' type="password" name='confirmpassword' class="form-control" placeholder="Confirm Password">
                    <input class='update-box' type="text" name='nick' class="form-control" placeholder="Nickname">
                </div>
                <br class="clear_float" />              
                <input type="submit" class="btn btn-default" value='Update' >
                <br class="clear_float" />
            </div>
        </div>
    </form>        
    <br class="clear_float" />
</div>
""" % (email, avatar, nick,  email, upload_avatar_form(email)) #subsitute names into html  
    
    start_response("200 OK", [('content-type', 'text/html')])
    return title, content

def update_profile_app(environ, start_response):
    """An app to update profile information"""
    title = "Update Profile"
    content = "Updating"
    
    #get data from form
    form = cgi.FieldStorage(environ=environ, fp=environ['wsgi.input'])
    email = form.getvalue("email", "")
    confirmemal = form.getvalue("confirmemail", "")
    password = form.getvalue("password", "")
    newpassword = form.getvalue("newpassword", "")
    confirmpass = form.getvalue("confirmpassword", "")
    nick = form.getvalue("nick", "")

    header = [('content-type', 'text/html'), ('location', '/new')]
    COOKIE_NAME = 'sessionid'
    checkpass = check_password(db, environ, db.crypt(password))
    
    #check email is valid
    if email != None and email != "":
        
        #update email address and assign new session
        newemail = update_email(db, environ, email)[0]
        delete_session(db, user_from_cookie(db, environ))
        session = generate_session(db, newemail)
        if session != None:
            print("THERE IS A SESSION CHANGING USERNAME")
            session = session[COOKIE_NAME].OutputString()
            header.append(('Set-Cookie', session))

        content += "<p>Your new email is: %s</p>" % newemail
        
    #check nickname is valid
    if nick != None and nick != "":
        
        #assign new nickname
        newnick = update_nick(db, environ, nick)
        content += "<p>Your new nickname is: %s</p>" % newnick
        
    #check password entered is current password
    if db.crypt(password) == checkpass:
        #check new password is same as confirmation password
        if newpassword == confirmpass:
            
            #update password
            newpass = update_password(db, environ, db.crypt(newpassword))
    else:
        print(db.crypt(password), "password not true")
        
    start_response("303 OK", header)
    return title, content

def new_app(environ, start_response):
    """Simple app to display what your new profile info has been updated to"""
    title = "Profile Updated"
    
    #get info from cookie
    email = user_from_cookie(db, environ)
    nick = nick_from_cookie(db, environ)[0][0]
    avatar = avatar_from_nick(db, environ)[0][0]
    
    content = """<div class='default-text'><p>Your profile has been updated!</p>
    <p>Your email is: %s</p>
    <p>Your nickname is: %s</p>
    <p>Your avatar is: %s</p>
    </div>""" % (email, nick, avatar)
    
    start_response("200 OK", [('content-type', 'text/html')])
    return title, content

def upload_avatar(environ, start_response):
    """This function checks if there has been a file added to the upload form,
        and if so it will load that file into the /static/images folder."""
        
    #get form data
    formdata = cgi.FieldStorage(environ=environ, fp=environ['wsgi.input'])
    email  = user_from_cookie(db, environ)
    
    title=""
    content=""
    
    #check something was entered
    if 'file' in formdata and formdata['file'].filename != '':
        
        file_data = formdata['file'].file.read()
        filename = formdata['file'].filename
        
        #direct to images folder inside static folder
        IMAGES_FILE_DIR = os.path.join(os.path.dirname(__file__), 'static' + '\images')
        path  = IMAGES_FILE_DIR
        
        #add filename to path
        target = os.path.join(IMAGES_FILE_DIR, filename)
        target = os.path.normpath(target) 
        
        #check path exists        
        if os.path.exists(path):
            title=""
            content=""
            addimg = add_avatar(db, filename, email)
            
            #check if image already exists
            if addimg == False:
                start_response("303 See Other", [('content-type', 'text/html'), ('location', '/profile')])
                
                #pass through the existing file path
                return filename
            
            else:
                # write the content of the uploaded file to a local file
                f = open(target, 'wb')
                f.write(file_data)
                f.close()  
                print(filename, "added image to file")
                
                title = "UPLOAD"
                content = "Uploading"
                start_response("303 See Other", [('content-type', 'text/html'), ('location', '/profile')])
                return filename
        else:
            title = "Upload Error"
            content = "<div class='default-text'><p>Could not upload file\nNo path</p></div>"
            start_response("303 See Other", [('content-type', 'text/html'), ('location', '/profile')])
            print("Couldnt upload")
            return False
        
    else:
        title = "Did he just click that button with no filename?"
        content = "I think he just did... Let's just ignore him until he stops..."
        start_response("303 See Other", [('content-type', 'text/html'), ('location', '/profile')])
        return False
#     return title, content

def upload_avatar_app(environ, start_response):
    """App to upload avatar picture"""
    
    #check filename of avatar
    filename = upload_avatar(environ, start_response)
    if filename != False:
        newavatar = update_avatar(db, environ, filename)
    return
        

def find_users(environ, start_response):
    """Simple app for the admin to check on user information"""
    
    #check email is admin
    email = user_from_cookie(db, environ)
    if email != "admin":
        start_response("303 See Other", [('content-type', 'text/html'), ('location', '/404')])
        title = ""
        content = ""
        return title, content
    title = "User List"
    users = get_users(db)
    content = "<div class='default-text'>"
    
    #display each user's info
    for item in users:
        for thingy in item:
            content += "<p>%s</p>" % thingy
        content += "<br/><br/><br/>"
    content += "</div>"
    start_response("200 OK", [('content-type', 'text/html')])
    return title, content
    
def application(environ, start_response):
    """Main WSGI Application for FlowTow"""
    
    #check the page extension and send off to each app
    if environ['PATH_INFO'].startswith('/static'):
        return static_app(environ, start_response)
        start_response("200 OK", [('content-type', 'text/html')])
    elif environ['PATH_INFO'] == '/about' or environ['PATH_INFO'] == '/about/':
        title = 'About FlowTow'
        content = """<div class='default-text'>
        <p>FlowTow is a new, exciting, photo sharing service like nothing you've seen before!</p>
        </div>"""
        start_response("200 OK", [('content-type', 'text/html')])
    elif environ['PATH_INFO'] == '/' or environ['PATH_INFO'] == '/index' or environ['PATH_INFO'] == '/home':
        title = 'Welcome to FlowTow'
        content = get_images(environ, 3)
#         get_login_data(environ, start_response)
        start_response("200 OK", [('content-type', 'text/html')])
        #get_form_data()
    elif environ['PATH_INFO'] == '/comment':
        title, content = comment_added_app(environ, start_response)
    elif environ['PATH_INFO'] == '/login':
        title, content = get_login_data(environ, start_response)
    elif environ['PATH_INFO'] == '/upload':
        title, content = upload_image(environ, start_response)
    elif environ['PATH_INFO'] == '/avatar':
        upload_avatar_app(environ, start_response)
        title = ""
        content = ""
    elif environ['PATH_INFO'] == '/my' or environ['PATH_INFO'] == '/myimages':
        title, content = get_my_images(environ, start_response)
    elif environ['PATH_INFO'] == '/reg' or environ['PATH_INFO'] == '/register':
        title, content = register_app(environ, start_response)
    elif environ['PATH_INFO'] == '/create':
        title, content = add_regi(environ, start_response)
    elif environ['PATH_INFO'] == '/delete':
        title, content = delete_image_app(environ, start_response)
    elif environ['PATH_INFO'] == '/profile':
        title, content = profile_app(environ, start_response)
    elif environ['PATH_INFO'] == '/update':
        title, content = update_profile_app(environ, start_response)
    elif environ['PATH_INFO'] == '/users':
        title, content = find_users(environ, start_response)
    elif environ['PATH_INFO'] == '/new':
        title, content = new_app(environ, start_response)
    else:
        title, content = show_404_app(environ, start_response)
        
    #get the menu and login info. Outside pages because it should remain universal
    menu = get_menu(environ)
    login = generate_login_form(environ)
    
    mapping = {
               'title': title,
               'content': content,
               'menu': menu,
               'login': login,
               }
        
    return render('index.html', mapping)
    
if __name__ == '__main__':
    
    from wsgiref import simple_server
    
    db = database.COMP249Db()
    
    #uncomment these to reset database on server run
#     db.create_tables()
#     db.sample_data()
      
    server = simple_server.make_server('localhost', 8000, application)
    print("listening on http://localhost:8000/ ...")
    server.serve_forever()
    
    