'''
Created on Mar 30, 2014

@author: Brett Sargeant
'''
import database
import sqlite3
import datetime

def check_image(db, filename):
    """Return a check on a proposed avatar"""
    query = "SELECT filename FROM images WHERE filename=?"
    cursor = db.cursor()
    cursor.execute(query, (filename,))
    test = cursor.fetchall()
    print(test, "image check filename")
    if test != None and test != '' and test != []:
        return test[0][0]
    else:
        print("Avatar not found - Set to default")
        return "default"

def list_comments(db, filename):
    """Return a list of the comments stored for this image filename"""
    query = "SELECT comment, nick, avatar FROM comments WHERE filename=?"
    query3 = "SELECT * FROM comments"
    cursor = db.cursor()
    cursor.execute(query3, )
    test = cursor.fetchall()
#     print(test, "test")
    
    cursor.execute(query, (filename,))
    commentlist = []
    comment = cursor.fetchall()
    print(comment)
    for item in comment:
#         print(item, "the item thingy")
        commentlist.append(item)
#     print(commentlist, "Newlist inside the list_comments")
    return commentlist


def add_comment(db, filename, comment, nick, avatar):
    """Add this comment to the database for this image filename"""
#     print( nick, "this is in add_comment")
    query = "INSERT INTO comments VALUES (?, ?, ?, ?)"
    cursor = db.cursor()
#     print(filename)
#     print(nick, "I BET THIS IS THE PROBELM")
    cursor.execute(query, (filename, comment, nick, avatar))
    db.commit()
    
    print( avatar, "this is in add_comment")
    

def list_images_for_user(db, email):
    """Return a count of how many images that user has uploaded"""
    query = "SELECT filename, date, useremail FROM images WHERE useremail LIKE (?) ORDER BY date DESC"
    cursor = db.cursor()
    cursor.execute(query, (email,))

    test = cursor.fetchall()
    cursor.execute(query, (email,))
    
    newlist = []
    count = 0
    #Iterate though each image until none left
    while len(test) > count:
        newlist2 = []
        image = cursor.fetchone()
        filename = image[0]
        comments = list_comments(db, filename)
        image = list(image)
        for item in comments:
            newlist2.append(item)

        #add the comments into the list then convert to tuple to be used
        image.append(newlist2)
        image = tuple(image)
        newlist.append(image)
        count += 1 
    return newlist

def list_images(db, n):
    """Return a list of tuples for the first 'n' images in 
    order of date.  Tuples should contain (filename, date, useremail, comments)."""
  
    query = "SELECT filename, date, useremail FROM images ORDER BY date DESC"
    cursor = db.cursor()
    cursor.execute(query,)
    
    newlist = []
    count = 0
    while n > count:
        newlist2 = []
        image = cursor.fetchone()
        filename = image[0]
        comments = list_comments(db, filename)

        image = list(image)
        for item in comments:
            newlist2.append(item)

        image.append(newlist2)
        
        image = tuple(image)
        newlist.append(image)
        count += 1
        
    return newlist

def add_user(db, useremail, password, nick, avatar):
    """Add a user to the database"""
    query = 'INSERT INTO users(email, password, nick, avatar) VALUES (?, ?, ?, ?)'
    query2 = 'SELECT email FROM users WHERE email=?'
    cursor = db.cursor()
    cursor.execute(query2, (useremail,))
    email = cursor.fetchone()
    
    if email != None:
        if email[0] == useremail:
            return False
    
    cursor.execute(query, (useremail, db.crypt(password), nick, avatar))
    db.commit()
    return True

def delete_image(db, filename, useremail):
    """Delete selected image from the database"""
    query = 'DELETE FROM images WHERE filename=? AND useremail=?'
    query2 = 'DELETE FROM comments WHERE filename=?'
#     print("Am i being called?")
    cursor = db.cursor()
    cursor.execute(query, (filename, useremail,))
    cursor.execute(query2, (filename,))
    db.commit()
    return True
    
def add_image(db, fname, useremail):
    """Add this image to the database for the given user also
       add a timestamp to the image so it can be ordered properly"""
    query2 = 'SELECT filename FROM images WHERE filename=?'
    query = 'INSERT INTO images(filename, date, useremail) VALUES ( ?, ?, ?)'

    cursor = db.cursor()
    cursor.execute(query2, (fname,))
    file = cursor.fetchone()
    if file != None:
        return False
    
    date = datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S%p")
    cursor.execute(query, (fname, date, useremail, ))
    db.commit()
    return True

def add_avatar(db, fname, email):
    """Check if avatar image is already uploaded. If it has,
        get that image filename location. If not, upload the image"""
        
    query = 'SELECT filename FROM images WHERE filename=?'
    cursor = db.cursor()
    cursor.execute(query, (fname,))
    file = cursor.fetchone()
    
    if file != None:
        return False
    
    query2 = 'INSERT INTO images(filename, date, useremail) VALUES ( ?, ?, ?)'
    date = datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S%p")
    cursor.execute(query2, (fname, date, email, ))
    db.commit()

    cursor.execute(query, (fname,))
    file = cursor.fetchone()
    
    print(file, "file")
    return True
    
    
    
    
    
    