	Author: Brett Sargeant
	Assignment: Comp249 Webtech
	Level: 5
	
	Changes: 
	
	1.	Change the date handling to allow correct order by date.
		The timestamp is added to the SQL server, then changed to y-m-d on generation.
		**Caution** This may cause some older images to not display a date.
		
	2.	Added a div container around the comments to allow for proper overflow scrolling in the css.
	
	3.	When I am not logged in, show a register button to allow new users to create an account.
		Added a register button when not logged in

	4.	In the register tab, allow the new user to pass in an email, password, nickname and avatar.
		Can register via the register page passing a email, password, nickname and avatar to the users table.

	5.	Under each image in My Images, I want a button to delete that image from the website.
		Added a delete button to My Images so the user can delete their own photos from the database.

	6. 	When I view a image's comments, I want to see a profile picture and a nickname. If the user is not logged in,
		I want the comments to show the nickname as "Anonymous".
		Reconfigured all the comment structures to include nicknames. The comments also store avatars.
		Will now show all comments with designated nickname. If none, then "Anonymous"
		
	7.	When I am logged in, I want to see a Profile button in the menu bar. Inside the profile page, I want to see my avatar,
		nickname and email. I also want a form so I can change my email, password and nickname. I want a password check when trying
		to change password. I also want an upload form so I can upload a image to be used as an avatar.
		
		Added a separate tab to the menu when logged in called Profile. The profile page contains information about your nickname and email,
		as well as displaying an avatar on the left. It also has a separate box to update you information.
		7.1	Section to update you email, with a confirmation retype your new email box to make sure you do not mispell your new email.
		7.2	Section to update you password, involving entering you current password, and a confirmation new password to make sure you do not
			mispell your new password.
		7.3	Section to change your nickname.
		7.4 Section to upload a new avatar photo. If the filename already exists, just use that. If not, upload images.
		
	8.	If logged in as "admin" create a users tab in the menu to show a list of users.
		Users button made for admin only.