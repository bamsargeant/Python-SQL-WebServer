'''
Created on Mar 26, 2012

@author: steve
'''

from http.cookies import SimpleCookie
import uuid

# this variable MUST be used as the name for the cookie used by this application
COOKIE_NAME = 'sessionid'

def check_login(db, useremail, password):
    """returns True if password matches stored"""
    
    query = "SELECT password FROM users WHERE email LIKE (?)"
    query2 = "SELECT email FROM users WHERE email LIKE (?)"
    cursor = db.cursor()
   
    cursor.execute(query2, (useremail,))
    checkemail = cursor.fetchone()
    
    #if email doesnt exist, return false
    if not checkemail:
        return False
    

    checkemail = list(checkemail)
    cursor.execute(query, (useremail,))
    
    #make sure email matches entered email
    if checkemail[0] != useremail:
        return False;

    
    checkpass = list(cursor.fetchone())
    
    #make sure entered password matches database password
    if db.crypt(password) == checkpass[0]:
        return True;
    else:
        return False;

def check_password(db, environ, password):
    """function to check if password given is same as username's"""
    query = "SELECT password FROM users WHERE email=?"
    cursor = db.cursor()
    email = user_from_cookie(db, environ)
    cursor.execute(query, (email,))
    checkpass = cursor.fetchone()

    if checkpass == None:
        return None
    if checkpass[0] == password:
        return password
    else:
        return None
    

def generate_session(db, useremail):
    """create a new session, return a cookie obj with session key
    user must be a valid user in the database, if not, return None
    There should only be one session per user at any time, if there
    is already a session active, the cookie should use the existing
    sessionid
    """

    cursor = db.cursor()    
    query = 'INSERT INTO sessions VALUES (?, ?)'
    query2 = "SELECT sessionid FROM sessions WHERE useremail=?"
    query3 = "SELECT email FROM users WHERE email=?"
    
    cursor.execute(query3, (useremail,))
    validemail = cursor.fetchone()
    
    if validemail == None:
        return None
    
    cursor.execute(query2, (useremail,))
    session = cursor.fetchone()
    print(session, "IS SESSION THERE?")
    
    if session == None:
        key = str(uuid.uuid4())    
        cursor.execute(query, (key, useremail,))
        db.commit()
        print("NO")
    else:
        key = session[0]
        print(session)
        print("YES")

    
    cookie = SimpleCookie() 
    cookie[COOKIE_NAME] = key 
    return cookie
    

def delete_session(db, useremail):
    """remove all session table entries for this user"""
    query = 'DELETE FROM sessions WHERE useremail LIKE (?)'
    cursor = db.cursor()
    cursor.execute(query, (useremail,) )
    
    query2 = "SELECT sessionid, useremail FROM sessions"
    cursor.execute(query2,)
    db.commit()

def user_from_cookie(db, environ):
    """check whether HTTP_COOKIE set, if it is,
    and if our cookie is present, try to
    retrieve the user email from the sessions table
    return useremail or None if no valid session is present"""
    
    query = "SELECT useremail FROM sessions WHERE sessionid=?"
    query2 = "SELECT sessionid FROM sessions"
    cursor = db.cursor()
#     print(sessions, "sessions")
    
    if 'HTTP_COOKIE' in environ:
            cookie = SimpleCookie(environ['HTTP_COOKIE'])
            if COOKIE_NAME in cookie :
                cur_session = cookie[COOKIE_NAME].value 
                
                cursor.execute(query, (cur_session,))
                checksession = cursor.fetchone() 
                
                if checksession != None:
                    return checksession[0]

    return None

def nick_from_cookie(db, environ):
    """Retrieve the nickname from the email based in the cookie"""
    email = user_from_cookie(db, environ)
    query = "SELECT nick FROM users WHERE email=?"
    cursor = db.cursor()
    if email != None:
        cursor.execute(query, (email,))
        nick = cursor.fetchall()
        print(nick, "Nick")
        if nick != None:
            return nick
    return None
        
def avatar_from_nick(db, environ):
    """A function to retrieve the avatar based on the nick from cookie"""
    nick = nick_from_cookie(db, environ)
    query = 'SELECT avatar FROM users WHERE nick=?'
    cursor = db.cursor()
    
    if nick != None and nick != '':
        cursor.execute(query, (nick[0][0],))
        avatar = cursor.fetchall()
        print(avatar, "The avatar")
        if avatar != None:
            return avatar
    return None
    
def update_email(db, environ, newemail):
    """An app to update the email"""
    email = user_from_cookie(db, environ)
    if email != None and newemail != None:
        query = 'UPDATE users SET email=? WHERE email=?'
        cursor = db.cursor()
        cursor.execute( query, (newemail, email,))
        db.commit() 
        
        query3 = "SELECT email FROM users WHERE email=?"
        cursor.execute( query3, (newemail,))
        updatedemail = cursor.fetchone()
        
        return updatedemail
    return None

def update_nick(db, environ, newnick):
    """An app to update the nickname"""
    email = user_from_cookie(db, environ)
    nick = nick_from_cookie(db, environ)
    if nick != None and newnick != None and email != None:
        query = "UPDATE users SET nick=? WHERE email=?"
        cursor = db.cursor()
        cursor.execute( query, (newnick, email,))
        db.commit() 
        
        query3 = "SELECT nick FROM users WHERE nick=? AND email=?"
        cursor.execute( query3, (newnick, email,))
        updatednick = cursor.fetchone()
        
        return updatednick
    return None

def update_avatar(db, environ, newavatar):
    """An app to update the avatar"""
    email = user_from_cookie(db, environ)
    avatar = avatar_from_nick(db, environ)
    if avatar != None and newavatar != None and email != None:
        query = "UPDATE users SET avatar=? WHERE email=?"
        cursor = db.cursor()
        cursor.execute( query, (newavatar, email,))
        db.commit()
        
        query3 = "SELECT avatar FROM users WHERE avatar=? AND email=?"
        cursor.execute( query3, (newavatar, email,))
        updatedavatar = cursor.fetchone()
        
        return updatedavatar
    return None

def update_password(db, environ, newpass):
    """A pass to update password"""
    email = user_from_cookie(db, environ) 
    
    if newpass != None and newpass != "" and email != None:
        query = "UPDATE users SET password=? WHERE email=?"
        cursor = db.cursor()
        cursor.execute( query, (newpass, email,))
        db.commit()
        
        query3 = "SELECT password FROM users WHERE email=?"
        cursor.execute( query3, (email,))
        updatedpass = cursor.fetchone()
        print(updatedpass, "PASSWORD CHANGED")
        return updatedpass
    
    return None
        
    
def get_users(db):
    """Return a list of users"""
    query = "SELECT * FROM users"   
    cursor = db.cursor()
    cursor.execute(query,)              
    return cursor.fetchall()         
            
            
